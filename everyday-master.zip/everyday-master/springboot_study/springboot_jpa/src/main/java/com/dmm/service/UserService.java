package com.dmm.service;

import com.dmm.entry.User;

public interface UserService {

    void addUser(User user);
}
