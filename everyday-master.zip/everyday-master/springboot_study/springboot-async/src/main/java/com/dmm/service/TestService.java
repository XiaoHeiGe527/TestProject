package com.dmm.service;

/**
 * @author DMM
 * @create 2019/10/12
 */

public interface TestService {

    String a() throws InterruptedException;

    String b();

    String c();

}

