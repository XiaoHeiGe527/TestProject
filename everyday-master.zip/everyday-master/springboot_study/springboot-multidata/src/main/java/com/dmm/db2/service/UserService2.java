package com.dmm.db2.service;

import com.dmm.entry.User;

public interface UserService2 {
    void addUser(String name, String password);
    void add(User user);
}
