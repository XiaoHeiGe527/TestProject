package com.dmm.db1.service;

import com.dmm.entry.User;

public interface UserService1 {
    void addUser(String name,String password);

    void add(User user);
}
