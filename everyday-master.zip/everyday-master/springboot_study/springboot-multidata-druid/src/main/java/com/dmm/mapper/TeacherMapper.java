package com.dmm.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.dmm.entity.Teacher;

public interface TeacherMapper extends BaseMapper<Teacher> {
}
