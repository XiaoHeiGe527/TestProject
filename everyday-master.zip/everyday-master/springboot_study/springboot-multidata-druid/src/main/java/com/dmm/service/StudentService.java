package com.dmm.service;

import com.baomidou.mybatisplus.service.IService;
import com.dmm.entity.Student;

public interface StudentService extends IService<Student> {
}
