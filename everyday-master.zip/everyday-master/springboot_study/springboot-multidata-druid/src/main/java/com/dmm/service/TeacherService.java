package com.dmm.service;

import com.baomidou.mybatisplus.service.IService;
import com.dmm.entity.Teacher;

public interface TeacherService extends IService<Teacher> {
}
