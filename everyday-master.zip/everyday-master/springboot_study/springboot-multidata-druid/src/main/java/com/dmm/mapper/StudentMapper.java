package com.dmm.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.dmm.entity.Student;

public interface StudentMapper extends BaseMapper<Student> {
}
