//package com.dmm.email;
//
///**
// * @author DMM
// * @create 2019/9/25
// */
//
//public class Test1 {
//
//    public static void main(String[] args) {
//        int a =100,b=50,c=a---b,d=a---b;
//
//        System.out.println(a);
//        System.out.println(b);
//        System.out.println(c);
//        System.out.println(d);
//    }
//}
//
