//package com.dmm.util;
//
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Component;
//
///**
// * @author DMM
// * @create 2019/9/6
// */
//@Component
//public class StringRedisTool<String,Stirng> extends StringRedisTemplate {
//
//
//}
//
