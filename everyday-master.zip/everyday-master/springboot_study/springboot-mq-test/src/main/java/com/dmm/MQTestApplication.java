package com.dmm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author DMM
 * @create 2019/8/28
 */
@SpringBootApplication
public class MQTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(MQTestApplication.class,args);
    }
}

