//package com.dmm.test;
//
///**
// * @author Mr. Du
// * @explain
// * @createTime 2019/11/8 13:32
// * @motto The more learn, the more found his ignorance.
// */
//
//public class Test1 {
//
//    public static void main(String[] args) {
//        test1();
//        test2();
//
//        Test1 test1=new Test1();
//        test1.test3();
//        test1.test4();
//
//    }
//
//    private static int a=1;
//
//    public static void test1(){
//        a++;
//        System.out.println(a);
//    }
//
//    public static void test2(){
//        a++;
//        System.out.println(a);
//    }
//
//    private int b=1;
//
//    public void test3(int i){
//        b+=i;
//        System.out.println(b);
//    }
//
//    public void test4(){
//        b++;
//        System.out.println(b);
//    }
//
//
//
//}
//
