package com.dmm.pojo.vo;

/**
 * @author DMM
 * @create 2019/11/5
 */

public class ExcelException extends RuntimeException {
    public ExcelException(String message) {
        super(message);
    }
}

