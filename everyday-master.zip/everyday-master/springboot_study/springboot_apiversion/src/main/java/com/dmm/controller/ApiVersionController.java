//package com.dmm.controller;
//
//import com.dmm.common.api.version.ApiVersion;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
///**
// * @author DMM
// * @create 2019/7/11
// */
//@RestController
//@RequestMapping(value = "/api/version")
//
//public class ApiVersionController {
//
//
//    @RequestMapping("/1")
//    @ApiVersion
//    public String get(){
//        return "hello";
//    }
//
//    @RequestMapping("/1")
//    @ApiVersion(20190415)
//    public String get2(){
//        return "hello3";
//    }
//
//
//}
//
