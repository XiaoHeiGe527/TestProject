//package com.dmm;
//
//import com.dmm.utils.PaySend;
//import com.dmm.utils.RabbitmqUtils;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class PayMqTest {
//
//    @Autowired
//    private PaySend paySend;
//
//    @Autowired
//    private RabbitmqUtils rabbitmqUtils;
//
//    @Test
//    public void setPaySend(){
//        paySend.paysend1();
//    }
//
//    @Test
//    public void setUtils(){
//        rabbitmqUtils.sendCC(111111111111111l);
//    }
//}
